MI FINANZAS — PROYECTO ANDROID

Este archivo es el proyecto fuente de Android Studio; todavía NO es un APK compilado.

Incluye:
- Aplicación Android sencilla que abre la calculadora incluida sin conexión.
- Plan sugerido de 20% para gastos, 10% para emergencias y el resto para metas.
- Objetivo Mazda de S/ 80,000 y meta configurable para negocio.
- Registro de movimientos y almacenamiento local del navegador integrado.

CÓMO GENERAR EL APK
1. Instala Android Studio en una computadora.
2. Abre la carpeta MiFinanzas como proyecto existente.
3. Espera a que Gradle sincronice y descargue los componentes solicitados.
4. Selecciona Build > Build Bundle(s) / APK(s) > Build APK(s).
5. El APK de depuración suele quedar en app/build/outputs/apk/debug/app-debug.apk.

NOTAS
- En este entorno no se dispone del Android SDK/Gradle necesarios para compilar y verificar el APK.
- Los datos se guardan localmente en el dispositivo; no se sincronizan con cuentas bancarias ni con la nube.
- Haz copias de seguridad de tus datos desde la aplicación.
